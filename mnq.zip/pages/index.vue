<template>
    <div class="min-h-screen flex items-center justify-center">
      <TerminalWindow />
    </div>
  </template>
  
  <script setup>
  import TerminalWindow from "@/components/TerminalWindow.vue";
  </script>
  